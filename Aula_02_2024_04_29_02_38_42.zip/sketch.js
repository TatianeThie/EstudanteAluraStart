function setup() {
  createCanvas(600, 600);
  background ("black");
}

function draw() {
  stroke ("blue");
  fill("red");
function setup() {
  createCanvas(600, 600);
 
}








  
  


  

 
    
  

